import mysql.connector

con=mysql.connector.connect(host='bvp3rfroyowpwzv2h4ip-mysql.services.clever-cloud.com',user='ufctgvy7mhd7chlf',password='j7pk0ZclF2XQXhO0JT1m',database='bvp3rfroyowpwzv2h4ip')
curs=con.cursor()


author=input("Enter the name of Author : ")
publication=input("Enter the name of Publication : ")

curs.execute("select * from books where author='%s' and publication='%s';" %(author,publication))
rec=curs.fetchone()


try:
    print("-------------------------------------")
    print("The bookname is :- %s" %rec[1])
    print("-------------------------------------")
except:
    print("book not found")

con.close() 