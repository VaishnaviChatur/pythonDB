
import mysql.connector

con=mysql.connector.connect(host='bvp3rfroyowpwzv2h4ip-mysql.services.clever-cloud.com',user='ufctgvy7mhd7chlf',password='j7pk0ZclF2XQXhO0JT1m',database='bvp3rfroyowpwzv2h4ip')
curs=con.cursor()

curs.execute("select * from books")
all=curs.fetchall()

for one in all:
    
    print("book-code : %s" %one[0])
    print("book-Name : %s" %one[1])
    print("Category : %s" %one[2])
    print("Author : %s" %one[3])
    print("Publication : %s" %one[4])
    print("Edition : %d" %one[5])
    print("Price : %d" %one[6])
    print('-------------------------------')

con.close()    