import mysql.connector

con=mysql.connector.connect(host='bvp3rfroyowpwzv2h4ip-mysql.services.clever-cloud.com',user='ufctgvy7mhd7chlf',password='j7pk0ZclF2XQXhO0JT1m',database='bvp3rfroyowpwzv2h4ip')
curs=con.cursor()

bcode=input("Enter a bookcode : ")


curs.execute("select bookcode from books where bookcode='%s';"%(bcode))
one=curs.fetchone()
try:
        if bcode in one:
            price=int(input("set the price do you want to update : "))
            curs.execute("update books set price='%d' where bookcode='%s';"%(price,bcode))
            con.commit()

            print("Price Updated")
            print("price of bookcode %s is now %d "%(bcode,price))
      
except:
        print("Book Addition failed")  
