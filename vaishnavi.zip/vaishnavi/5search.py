import mysql.connector

con=mysql.connector.connect(host='bvp3rfroyowpwzv2h4ip-mysql.services.clever-cloud.com',user='ufctgvy7mhd7chlf',password='j7pk0ZclF2XQXhO0JT1m',database='bvp3rfroyowpwzv2h4ip')
curs=con.cursor()

s=input("Enter the Book Code : ")

curs.execute("select bookcode,bookname,category,author,publication,edition,price from books where bookcode='%s'" %s)
rec=curs.fetchone()


try:
    
    print("Book-Name     : %s" %rec[1])
    print("Category      : %s" %rec[2])
    print("Author        : %s" %rec[3])
    print("Publication   : %s" %rec[4])
    print("Edition       : %d" %rec[5])
    print("Price         : %d" %rec[6])
    
except:
    print("book not found")

con.close() 