import mysql.connector

con=mysql.connector.connect(host='bvp3rfroyowpwzv2h4ip-mysql.services.clever-cloud.com',user='ufctgvy7mhd7chlf',password='j7pk0ZclF2XQXhO0JT1m',database='bvp3rfroyowpwzv2h4ip')
curs=con.cursor()

b=input("Enter the Bookcode : ")

curs.execute("select bookcode from books where bookcode='%s';"%(b))
one=curs.fetchone()
try:
    if b in one:
        r=input("Write the Review : ")
        curs.execute("update books set review='%s' where bookcode='%s';"%(r,b))
        con.commit()
        print("Review will be Submmited")

except:
 print("Book is not present....")  
