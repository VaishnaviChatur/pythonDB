import mysql.connector

con=mysql.connector.connect(host='bvp3rfroyowpwzv2h4ip-mysql.services.clever-cloud.com',user='ufctgvy7mhd7chlf',password='j7pk0ZclF2XQXhO0JT1m',database='bvp3rfroyowpwzv2h4ip')
curs=con.cursor()
category=input("Enter the category : ")
curs.execute("select * from books where category='%s'" %category)
all=curs.fetchall()
print("List of book with category %s"%category+" is ")
for one in all:
    
    print(" ----> %s" %one[1])
    

con.close()    
 